package com.example.implicitintent;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ImplicitActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_implicit);

        Button btnCallPolice = findViewById(R.id.btnCallPolice);
        Button btnCallFireDepartment = findViewById(R.id.btnCallFireDepartment);
        Button btnCallHospital = findViewById(R.id.btnCallHospital);

        btnCallPolice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callNumber("110"); // Nomor Polisi
            }
        });

        btnCallFireDepartment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callNumber("113"); // Nomor Pemadam Kebakaran
            }
        });

        btnCallHospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callNumber("118"); // Nomor Rumah Sakit
            }
        });
    }

    private void callNumber(String number) {
        Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
        if (callIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(callIntent);
        } else {
            Toast.makeText(this, "Tidak ada aplikasi yang dapat melakukan panggilan.", Toast.LENGTH_SHORT).show();
        }
    }
}
